
<html>

<header>
<div class="container">
            <div class="row">
                <div class="col-4">
                    <h1>Payroll Solutions</h1>

                </div>
                <div class="col-4"></div>
                <div class="col-4">
                    <br>
                    <p> Logged in as: <?php echo $login_account;
                     echo "<img src='photos/".$login_photo."'>"?> 
                     <br> <a href="logout.php">Logout</a></p>
                     <p>
                    
                    
                </div>

            </div>

            <div class="row">
                <div class="col-6">
                    <p class="title">Payroll and Payslip system</p>
                </div>
                <div class="col-6"></div>

            </div>


        </div>

</header>
</html>
