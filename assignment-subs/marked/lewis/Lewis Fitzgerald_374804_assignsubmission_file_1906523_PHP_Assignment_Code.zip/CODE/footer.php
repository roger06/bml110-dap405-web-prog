<html>

<footer>
<div class="row">
    <div class="col-12">
        <article>
            <a href="https://www.twitter.com/"> <i class="fab fa-twitter-square"></i></a>
            <a href="https://www.facebook.com/"> <i class="fab fa-facebook-square"></i></a>
            <a href="https://www.instagram.com/"> <i class="fab fa-instagram-square"></i></a>
            <a href="https://www.linkedin.com/"> <i class="fab fa-linkedin"></i></a>
            <a href="solutiuons@pay.co.uk"> <i class="fas fa-inbox"></i></a>

            <p>Contents <i id="copyright" class="far fa-copyright"></i> Payroll Solutions</p>
        </article>
    </div>
</div>

</footer>
</html>

