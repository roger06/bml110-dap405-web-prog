<?php
ini_set('display_errors', '0');
session_start();
require "getJson.php";
require "auth.php";
require "layout.php";

//No music videos this time :(
?>
<link rel="stylesheet" href="css/simple.css">
<div>
    <h2>ERROR 404: Employee not found</h2>
</div>
</body>
</html>
