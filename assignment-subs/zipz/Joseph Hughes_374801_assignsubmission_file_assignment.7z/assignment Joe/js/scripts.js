<script type="text/javascript">
    function alert(txt){
        var alertMsg = txt;
        (alertMsg);
    }
</script>