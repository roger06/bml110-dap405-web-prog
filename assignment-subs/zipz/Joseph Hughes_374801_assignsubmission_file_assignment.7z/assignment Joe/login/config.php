<?php

$users = array(
    array(
        'id' => 1,
        'username' => 'Admin',
        'password' => 'password',
    ),
    array(
        'id' => 2,
        'username' => 'User',
        'password' => 'password',
    ),
    array(
        'id' => 3,
        'username' => 'user1',
        'password' => 'password',
    )
);
?>