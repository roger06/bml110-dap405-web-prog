<link rel="stylesheet" href="css/styles.css"/>

<form class="form_login" action="login/process.php" method="post">
    <h1>Login</h1>
    <p class="login_text">Username: </p> <input type="text" name="username" default = "username">
    <p class="login_text">Password: </p> <input type="password" name="password" default = "password">
    <input type="submit" value="Login">
</form>
    