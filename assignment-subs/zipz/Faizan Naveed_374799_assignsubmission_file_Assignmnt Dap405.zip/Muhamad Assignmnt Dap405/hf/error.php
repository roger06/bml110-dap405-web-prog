<div class="error">
    <h2>User Does not Exit</h2>
</div>