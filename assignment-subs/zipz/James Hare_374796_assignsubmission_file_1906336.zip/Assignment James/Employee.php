<?php

class Employee {
    public stdClass $Details;
    public int $Tax;
    function ___constructor(stdClass $employeedata){
        $Details = $employeedata;

    }
    





}

?>