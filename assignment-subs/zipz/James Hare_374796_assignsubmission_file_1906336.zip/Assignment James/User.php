<?php 


class User{
    
    public string $PermisionLevel;

    public string $UserName;
    public $Data; 
    public float $tax;
}
?>