<?php
namespace configs; 
// abstract class AbsConfig{
//     public array $configOptions;
//    abstract public function UpdateConfig(string $paramName,$paramVal);

// }
?>