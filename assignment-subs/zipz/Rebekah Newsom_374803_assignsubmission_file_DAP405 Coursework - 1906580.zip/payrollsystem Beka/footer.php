 <!-- Footer for all pages -->
 <link rel="stylesheet" type="text/css" href="footer.css" />
 <footer class="text-muted py-2">
   <div class="footer">
     <p class="float-end mb-1">Perk Payroll System &copy; 2020</p>
     </p>
   </div>

   </body>

   </html>