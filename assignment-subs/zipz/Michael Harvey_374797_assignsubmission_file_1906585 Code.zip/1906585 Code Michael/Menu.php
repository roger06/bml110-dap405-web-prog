<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<style>
			.margin {
				margin-left: 2em !important;
				margin-right: 2em !important;
			}
		</style>
	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="nav navbar-nav">
				<a class="nav-item nav-link" href='homePage.php'><strong class="margin">Home</strong></a>
				<a class="nav-item nav-link" href='TaxTable.php'><strong class="margin">Tax Table</strong></a>
				<a class="nav-item nav-link" href='ViewAccount.php'><strong class="margin">Your Account</strong></a>
				<a class="nav-item nav-link" href='login.php'><strong class="margin">Logout</strong></a>
			</div>
		</nav>
